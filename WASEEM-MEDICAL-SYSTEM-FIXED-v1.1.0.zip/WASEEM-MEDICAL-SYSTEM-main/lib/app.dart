import 'package:flutter/material.dart';
import 'screens/splash_screen.dart';
import 'services/settings_service.dart';

class WaseemMedicalApp extends StatefulWidget {
  const WaseemMedicalApp({super.key});
  @override
  State<WaseemMedicalApp> createState() => _WaseemMedicalAppState();
}

class _WaseemMedicalAppState extends State<WaseemMedicalApp> {
  bool dark = false;

  @override
  void initState() {
    super.initState();
    _loadSettings();
  }

  Future<void> _loadSettings() async {
    final value = await SettingsService.instance.isDarkMode();
    if (mounted) setState(() => dark = value);
  }

  Future<void> toggleTheme() async {
    final value = !dark;
    await SettingsService.instance.setDarkMode(value);
    if (mounted) setState(() => dark = value);
  }

  @override
  Widget build(BuildContext context) {
    const seed = Color(0xFF0B7891);
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'وسيم ميديكال',
      themeMode: dark ? ThemeMode.dark : ThemeMode.light,
      theme: ThemeData(useMaterial3: true, colorScheme: ColorScheme.fromSeed(seedColor: seed), scaffoldBackgroundColor: const Color(0xFFF4F8FB), fontFamily: 'Arial', inputDecorationTheme: const InputDecorationTheme(border: OutlineInputBorder(borderRadius: BorderRadius.all(Radius.circular(14))))),
      darkTheme: ThemeData(useMaterial3: true, colorScheme: ColorScheme.fromSeed(seedColor: seed, brightness: Brightness.dark), fontFamily: 'Arial'),
      locale: const Locale('ar'),
      home: SplashScreen(onThemeChanged: toggleTheme),
    );
  }
}
