import 'package:flutter/material.dart';
import 'departments_screen.dart';
import 'finance_screen.dart';
import 'reports_screen.dart';
import 'sessions_screen.dart';
import 'settings_screen.dart';
import 'staff_screen.dart';

class MoreScreen extends StatelessWidget {
  const MoreScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final items = <_MoreItem>[
      _MoreItem('الإدارة المالية', Icons.account_balance_wallet, const FinanceScreen()),
      _MoreItem('الجلسات والباقات', Icons.healing, const SessionsScreen()),
      _MoreItem('الأقسام والخدمات', Icons.medical_services, const DepartmentsScreen()),
      _MoreItem('الكادر والموظفون', Icons.groups, const StaffScreen()),
      _MoreItem('التقارير', Icons.bar_chart, const ReportsScreen()),
      _MoreItem('الإعدادات', Icons.settings, const SettingsScreen()),
    ];
    return Scaffold(
      appBar: AppBar(title: const Text('المزيد')),
      body: ListView.separated(padding: const EdgeInsets.all(12), itemCount: items.length, separatorBuilder: (_, __) => const SizedBox(height: 8), itemBuilder: (context, index) {
        final item = items[index];
        return Card(elevation: 0, child: ListTile(leading: CircleAvatar(child: Icon(item.icon)), title: Text(item.title, style: const TextStyle(fontWeight: FontWeight.w600)), trailing: const Icon(Icons.chevron_left), onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => item.page))));
      }),
    );
  }
}

class _MoreItem {
  final String title;
  final IconData icon;
  final Widget page;
  const _MoreItem(this.title, this.icon, this.page);
}
