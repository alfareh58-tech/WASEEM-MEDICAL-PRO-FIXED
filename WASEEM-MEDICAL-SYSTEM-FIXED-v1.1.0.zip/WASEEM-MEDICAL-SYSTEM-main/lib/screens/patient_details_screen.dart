import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../services/database_service.dart';
import '../services/messaging_service.dart';
import '../services/settings_service.dart';
import '../services/pdf_service.dart';

class PatientDetailsScreen extends StatefulWidget {
  final int patientId;
  const PatientDetailsScreen({super.key, required this.patientId});
  @override
  State<PatientDetailsScreen> createState() => _PatientDetailsScreenState();
}

class _PatientDetailsScreenState extends State<PatientDetailsScreen> {
  Map<String, Object?>? patient;
  bool loading = true;

  @override
  void initState() { super.initState(); load(); }

  Future<void> load() async {
    try {
      final data = await DatabaseService.instance.patient(widget.patientId);
      if (!mounted) return;
      setState(() { patient = data; loading = false; });
    } catch (e) {
      if (!mounted) return;
      setState(() => loading = false);
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('تعذر تحميل الملف: $e')));
    }
  }

  Future<void> sendWhatsApp() async {
    final p = patient;
    if (p == null) return;
    final phone = '${p['phone'] ?? ''}'.trim();
    if (phone.isEmpty) { _message('لا يوجد رقم هاتف لهذا المريض.'); return; }
    final center = await SettingsService.instance.centerName();
    final message = MessagingService.registrationMessage(
      patient: '${p['full_name'] ?? ''}',
      fileNo: '${p['file_no'] ?? ''}',
      center: center,
      service: '${p['service'] ?? p['department'] ?? ''}',
      date: DateFormat('yyyy/MM/dd').format(DateTime.tryParse('${p['created_at']}') ?? DateTime.now()),
      support: await SettingsService.instance.supportPhone(),
    );
    final ok = await MessagingService.whatsapp(phone, message);
    if (!ok) _message('تعذر فتح واتساب.');
  }

  void _message(String text) { if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text))); }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(patient == null ? 'ملف المريض' : '${patient!['full_name']}')),
      body: loading ? const Center(child: CircularProgressIndicator()) : patient == null ? const Center(child: Text('ملف المريض غير موجود.')) : ListView(padding: const EdgeInsets.all(14), children: [
        Card(elevation: 0, child: Padding(padding: const EdgeInsets.all(18), child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          Row(children: [const CircleAvatar(radius: 28, child: Icon(Icons.person)), const SizedBox(width: 12), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('${patient!['full_name']}', style: const TextStyle(fontSize: 21, fontWeight: FontWeight.bold)), Text('رقم الملف: ${patient!['file_no']}')]))]),
          const Divider(height: 28),
          _info('الهاتف', patient!['phone']), _info('الجنس', patient!['gender']), _info('العمر', patient!['age']), _info('تاريخ الميلاد', patient!['birth_date']), _info('العنوان', patient!['address']), _info('الهوية', patient!['national_id']), _info('القسم', patient!['department']), _info('الخدمة', patient!['service']), _info('الطبيب / الأخصائي', patient!['doctor']), _info('مصدر الإحالة', patient!['referral_source']), _info('الملاحظات', patient!['notes']),
        ]))),
        const SizedBox(height: 10),
        Wrap(spacing: 8, runSpacing: 8, children: [
          FilledButton.icon(onPressed: sendWhatsApp, icon: const Icon(Icons.message), label: const Text('واتساب')),
          OutlinedButton.icon(onPressed: () async { final center = await SettingsService.instance.centerName(); await PdfService.printPatientCard(patient!, center); }, icon: const Icon(Icons.print), label: const Text('طباعة PDF')),
          OutlinedButton.icon(onPressed: () async { final phone = '${patient!['phone'] ?? ''}'; final center = await SettingsService.instance.centerName(); final msg = MessagingService.registrationMessage(patient: '${patient!['full_name']}', fileNo: '${patient!['file_no']}', center: center, service: '${patient!['service'] ?? patient!['department'] ?? ''}', date: DateFormat('yyyy/MM/dd').format(DateTime.tryParse('${patient!['created_at']}') ?? DateTime.now()), support: await SettingsService.instance.supportPhone()); final ok = await MessagingService.sms(phone, msg); if (!ok) _message('تعذر فتح الرسائل.'); }, icon: const Icon(Icons.sms), label: const Text('SMS')),
        ]),
      ]),
    );
  }

  Widget _info(String title, Object? value) => Padding(padding: const EdgeInsets.symmetric(vertical: 5), child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [SizedBox(width: 125, child: Text(title, style: const TextStyle(fontWeight: FontWeight.bold))), Expanded(child: Text(value == null || '$value'.trim().isEmpty ? 'غير محدد' : '$value'))]));
}
