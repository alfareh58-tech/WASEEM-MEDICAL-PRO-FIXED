import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../services/database_service.dart';
import '../services/messaging_service.dart';
import '../services/pdf_service.dart';
import '../services/settings_service.dart';
import '../widgets/section_card.dart';

class AddPatientScreen extends StatefulWidget {
  const AddPatientScreen({super.key});
  @override
  State<AddPatientScreen> createState() => _AddPatientScreenState();
}

class _AddPatientScreenState extends State<AddPatientScreen> {
  final formKey = GlobalKey<FormState>();
  final name = TextEditingController();
  final phone = TextEditingController();
  final age = TextEditingController();
  final birth = TextEditingController();
  final address = TextEditingController();
  final nationalId = TextEditingController();
  final notes = TextEditingController();
  final service = TextEditingController();
  final doctor = TextEditingController();

  String gender = 'ذكر';
  String department = 'قسم الرجال';
  String referral = 'معرفة شخصية';
  List<Map<String, Object?>> departments = [];
  bool saving = false;

  @override
  void initState() { super.initState(); loadDepartments(); }

  @override
  void dispose() {
    for (final c in [name, phone, age, birth, address, nationalId, notes, service, doctor]) { c.dispose(); }
    super.dispose();
  }

  Future<void> loadDepartments() async {
    final data = await DatabaseService.instance.departments();
    if (!mounted) return;
    setState(() {
      departments = data;
      if (departments.isNotEmpty && !departments.any((d) => '${d['name']}' == department)) department = '${departments.first['name']}';
    });
  }

  Future<void> pickBirth() async {
    final selected = await showDatePicker(context: context, firstDate: DateTime(1920), lastDate: DateTime.now(), initialDate: DateTime(2000));
    if (selected != null) {
      birth.text = DateFormat('yyyy-MM-dd').format(selected);
      final now = DateTime.now();
      var calculatedAge = now.year - selected.year;
      if (DateTime(now.year, selected.month, selected.day).isAfter(now)) calculatedAge--;
      age.text = '$calculatedAge';
      setState(() {});
    }
  }

  Future<void> save({bool notify = false, bool print = false}) async {
    if (!formKey.currentState!.validate()) return;
    setState(() => saving = true);
    try {
      final fileNo = await DatabaseService.instance.nextFileNo();
      final now = DateTime.now();
      final data = <String, Object?>{
        'file_no': fileNo,
        'full_name': name.text.trim(),
        'phone': phone.text.trim(),
        'gender': gender,
        'age': int.tryParse(age.text.trim()),
        'birth_date': birth.text.trim(),
        'address': address.text.trim(),
        'national_id': nationalId.text.trim(),
        'department': department,
        'service': service.text.trim(),
        'doctor': doctor.text.trim(),
        'referral_source': referral,
        'notes': notes.text.trim(),
        'status': 'نشط',
        'created_at': now.toIso8601String(),
      };
      final id = await DatabaseService.instance.createPatient(data);
      final patient = <String, Object?>{...data, 'id': id};
      final center = await SettingsService.instance.centerName();

      if (print) await PdfService.printPatientCard(patient, center);

      if (notify) {
        final choice = await showModalBottomSheet<String>(context: context, showDragHandle: true, builder: (context) => SafeArea(child: Column(mainAxisSize: MainAxisSize.min, children: [
          ListTile(leading: const Icon(Icons.message), title: const Text('فتح واتساب'), onTap: () => Navigator.pop(context, 'wa')),
          ListTile(leading: const Icon(Icons.sms), title: const Text('فتح الرسائل SMS'), onTap: () => Navigator.pop(context, 'sms')),
        ])));
        final message = MessagingService.registrationMessage(patient: name.text.trim(), fileNo: fileNo, center: center, service: service.text.trim().isEmpty ? department : service.text.trim(), date: DateFormat('yyyy/MM/dd').format(now), support: await SettingsService.instance.supportPhone());
        if (choice == 'wa') await MessagingService.whatsapp(phone.text.trim(), message);
        if (choice == 'sms') await MessagingService.sms(phone.text.trim(), message);
      }

      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('تم حفظ المريض بنجاح — رقم الملف $fileNo')));
      Navigator.pop(context, true);
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('تعذر حفظ المريض: $e')));
    } finally {
      if (mounted) setState(() => saving = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final departmentItems = departments.isEmpty ? <DropdownMenuItem<String>>[const DropdownMenuItem(value: 'قسم الرجال', child: Text('قسم الرجال'))] : [for (final d in departments) DropdownMenuItem(value: '${d['name']}', child: Text('${d['name']}'))];
    return Scaffold(
      appBar: AppBar(title: const Text('إضافة مريض جديد')),
      body: Form(key: formKey, child: ListView(padding: const EdgeInsets.all(14), children: [
        SectionCard(title: 'البيانات الأساسية', icon: Icons.person, child: Column(children: [
          TextFormField(controller: name, decoration: const InputDecoration(labelText: 'الاسم الكامل *', prefixIcon: Icon(Icons.person)), validator: (v) => v == null || v.trim().isEmpty ? 'الاسم مطلوب' : null),
          const SizedBox(height: 10),
          TextFormField(controller: phone, keyboardType: TextInputType.phone, decoration: const InputDecoration(labelText: 'رقم الجوال *', prefixIcon: Icon(Icons.phone)), validator: (v) => v == null || v.trim().length < 7 ? 'أدخل رقم جوال صحيحًا' : null),
          const SizedBox(height: 10),
          Row(children: [Expanded(child: TextFormField(controller: nationalId, decoration: const InputDecoration(labelText: 'رقم الهوية'))), const SizedBox(width: 10), Expanded(child: TextFormField(controller: age, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'العمر')))]),
          const SizedBox(height: 10),
          Row(children: [Expanded(child: DropdownButtonFormField<String>(value: gender, decoration: const InputDecoration(labelText: 'الجنس'), items: const [DropdownMenuItem(value: 'ذكر', child: Text('ذكر')), DropdownMenuItem(value: 'أنثى', child: Text('أنثى'))], onChanged: (v) => setState(() => gender = v ?? gender))), const SizedBox(width: 10), Expanded(child: TextFormField(controller: birth, readOnly: true, onTap: pickBirth, decoration: const InputDecoration(labelText: 'تاريخ الميلاد', suffixIcon: Icon(Icons.calendar_month))))]),
          const SizedBox(height: 10),
          TextFormField(controller: address, decoration: const InputDecoration(labelText: 'العنوان *', prefixIcon: Icon(Icons.location_on)), validator: (v) => v == null || v.trim().isEmpty ? 'العنوان مطلوب' : null),
        ])),
        SectionCard(title: 'الخدمة والملف الطبي', icon: Icons.medical_services, child: Column(children: [
          DropdownButtonFormField<String>(value: department, isExpanded: true, decoration: const InputDecoration(labelText: 'القسم'), items: departmentItems, onChanged: (v) => setState(() => department = v ?? department)),
          const SizedBox(height: 10), TextFormField(controller: service, decoration: const InputDecoration(labelText: 'الخدمة')), const SizedBox(height: 10), TextFormField(controller: doctor, decoration: const InputDecoration(labelText: 'الطبيب / الأخصائي')), const SizedBox(height: 10),
          DropdownButtonFormField<String>(value: referral, decoration: const InputDecoration(labelText: 'مصدر المعرفة'), items: const [DropdownMenuItem(value: 'معرفة شخصية', child: Text('معرفة شخصية')), DropdownMenuItem(value: 'إحالة طبية', child: Text('إحالة طبية')), DropdownMenuItem(value: 'وسائل التواصل', child: Text('وسائل التواصل')), DropdownMenuItem(value: 'مريض سابق', child: Text('مريض سابق'))], onChanged: (v) => setState(() => referral = v ?? referral)),
          const SizedBox(height: 10), TextFormField(controller: notes, maxLines: 4, maxLength: 500, decoration: const InputDecoration(labelText: 'ملاحظات أولية')),
        ])),
        if (saving) const Padding(padding: EdgeInsets.all(12), child: Center(child: CircularProgressIndicator())),
        Wrap(spacing: 8, runSpacing: 8, children: [
          FilledButton.icon(onPressed: saving ? null : save, icon: const Icon(Icons.save), label: const Text('حفظ المريض')),
          OutlinedButton.icon(onPressed: saving ? null : () => save(notify: true), icon: const Icon(Icons.message), label: const Text('حفظ وإشعار')),
          OutlinedButton.icon(onPressed: saving ? null : () => save(print: true), icon: const Icon(Icons.print), label: const Text('حفظ وطباعة')),
        ]),
      ])),
    );
  }
}
