import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';

import '../services/database_service.dart';
import '../services/messaging_service.dart';
import '../services/settings_service.dart';

class FinanceScreen extends StatefulWidget {
  const FinanceScreen({super.key});

  @override
  State<FinanceScreen> createState() => _FinanceScreenState();
}

class _FinanceScreenState extends State<FinanceScreen> {
  double receipts = 0;
  double expenses = 0;
  double cashBalance = 0;
  double receivables = 0;
  List<Map<String, Object?>> recentReceipts = [];
  List<Map<String, Object?>> recentExpenses = [];
  List<Map<String, Object?>> expenseAccounts = [];
  bool loading = true;

  final _money = NumberFormat('#,##0.##', 'en_US');
  final _date = DateFormat('yyyy/MM/dd HH:mm', 'ar');

  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    setState(() => loading = true);
    try {
      final results = await Future.wait<dynamic>([
        DatabaseService.instance.todayReceipts(),
        DatabaseService.instance.todayExpenses(),
        DatabaseService.instance.cashBalance(),
        DatabaseService.instance.receivablesBalance(),
        DatabaseService.instance.recentReceipts(),
        DatabaseService.instance.recentExpenses(),
        DatabaseService.instance.expenseAccounts(),
      ]);
      if (!mounted) return;
      setState(() {
        receipts = results[0] as double;
        expenses = results[1] as double;
        cashBalance = results[2] as double;
        receivables = results[3] as double;
        recentReceipts = (results[4] as List).cast<Map<String, Object?>>();
        recentExpenses = (results[5] as List).cast<Map<String, Object?>>();
        expenseAccounts = (results[6] as List).cast<Map<String, Object?>>();
        loading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() => loading = false);
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('تعذر تحميل المالية: $e')));
    }
  }

  String money(num value) => _money.format(value);

  Future<void> receipt() async {
    final patients = await DatabaseService.instance.patients();
    if (patients.isEmpty) {
      _message('أضف مريضًا أولًا قبل إنشاء سند قبض.');
      return;
    }

    int patientId = (patients.first['id'] as num).toInt();
    final amount = TextEditingController();
    final description = TextEditingController();

    final result = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => StatefulBuilder(
        builder: (context, setDialogState) => AlertDialog(
          title: const Row(children: [Icon(Icons.receipt_long), SizedBox(width: 8), Text('سند قبض')]),
          content: SingleChildScrollView(
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              DropdownButtonFormField<int>(
                value: patientId,
                isExpanded: true,
                items: [
                  for (final patient in patients)
                    DropdownMenuItem<int>(
                      value: (patient['id'] as num).toInt(),
                      child: Text('${patient['file_no']} — ${patient['full_name']}', overflow: TextOverflow.ellipsis),
                    ),
                ],
                onChanged: (value) => setDialogState(() => patientId = value ?? patientId),
                decoration: const InputDecoration(labelText: 'المريض', prefixIcon: Icon(Icons.person)),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: amount,
                keyboardType: const TextInputType.numberWithOptions(decimal: true),
                decoration: const InputDecoration(labelText: 'المبلغ', prefixIcon: Icon(Icons.payments)),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: description,
                maxLines: 2,
                decoration: const InputDecoration(labelText: 'البيان', prefixIcon: Icon(Icons.notes)),
              ),
            ]),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(dialogContext, false), child: const Text('إلغاء')),
            FilledButton.icon(
              onPressed: () {
                final value = double.tryParse(amount.text.trim().replaceAll(',', '')) ?? 0;
                if (value <= 0) {
                  ScaffoldMessenger.of(dialogContext).showSnackBar(const SnackBar(content: Text('أدخل مبلغًا صحيحًا.')));
                  return;
                }
                Navigator.pop(dialogContext, true);
              },
              icon: const Icon(Icons.save),
              label: const Text('حفظ'),
            ),
          ],
        ),
      ),
    );

    if (result != true) {
      amount.dispose();
      description.dispose();
      return;
    }

    final value = double.tryParse(amount.text.trim().replaceAll(',', '')) ?? 0;
    final desc = description.text.trim();
    amount.dispose();
    description.dispose();

    try {
      final id = await DatabaseService.instance.createReceipt(
        patientId: patientId,
        amount: value,
        description: desc,
      );
      final data = await DatabaseService.instance.receiptById(id);
      await load();
      if (!mounted) return;
      await _showDocumentActions(
        type: 'receipt',
        number: '${data['receipt_no']}',
        patient: data,
        amount: value,
        description: desc,
        date: DateTime.parse('${data['receipt_date']}'),
      );
    } catch (e) {
      _message('تعذر حفظ سند القبض: $e');
    }
  }

  Future<void> expense() async {
    if (expenseAccounts.isEmpty) {
      _message('لا توجد حسابات مصروفات في دليل الحسابات.');
      return;
    }

    String category = '${expenseAccounts.first['name']}';
    final amount = TextEditingController();
    final description = TextEditingController();

    final result = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => StatefulBuilder(
        builder: (context, setDialogState) => AlertDialog(
          title: const Row(children: [Icon(Icons.money_off), SizedBox(width: 8), Text('سند صرف')]),
          content: SingleChildScrollView(
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              DropdownButtonFormField<String>(
                value: category,
                isExpanded: true,
                items: [
                  for (final account in expenseAccounts)
                    DropdownMenuItem<String>(value: '${account['name']}', child: Text('${account['name']}')),
                ],
                onChanged: (value) => setDialogState(() => category = value ?? category),
                decoration: const InputDecoration(labelText: 'حساب المصروف', prefixIcon: Icon(Icons.account_balance_wallet)),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: amount,
                keyboardType: const TextInputType.numberWithOptions(decimal: true),
                decoration: const InputDecoration(labelText: 'المبلغ', prefixIcon: Icon(Icons.payments)),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: description,
                maxLines: 2,
                decoration: const InputDecoration(labelText: 'البيان', prefixIcon: Icon(Icons.notes)),
              ),
            ]),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(dialogContext, false), child: const Text('إلغاء')),
            FilledButton.icon(
              onPressed: () {
                final value = double.tryParse(amount.text.trim().replaceAll(',', '')) ?? 0;
                if (value <= 0) {
                  ScaffoldMessenger.of(dialogContext).showSnackBar(const SnackBar(content: Text('أدخل مبلغًا صحيحًا.')));
                  return;
                }
                Navigator.pop(dialogContext, true);
              },
              icon: const Icon(Icons.save),
              label: const Text('حفظ'),
            ),
          ],
        ),
      ),
    );

    if (result != true) {
      amount.dispose();
      description.dispose();
      return;
    }

    final value = double.tryParse(amount.text.trim().replaceAll(',', '')) ?? 0;
    final desc = description.text.trim();
    amount.dispose();
    description.dispose();

    try {
      final expenseId = await DatabaseService.instance.createExpense(category: category, amount: value, description: desc);
      final rows = await DatabaseService.instance.db.query('expenses', where: 'id=?', whereArgs: [expenseId], limit: 1);
      await load();
      if (!mounted) return;
      final row = rows.isEmpty ? <String, Object?>{} : rows.first;
      await _showDocumentActions(
        type: 'expense',
        number: '${row['expense_no'] ?? ''}',
        patient: row,
        amount: value,
        description: desc,
        date: DateTime.tryParse('${row['expense_date']}') ?? DateTime.now(),
      );
    } catch (e) {
      _message('تعذر حفظ سند الصرف: $e');
    }
  }

  Future<void> _showDocumentActions({
    required String type,
    required String number,
    required Map<String, Object?> patient,
    required double amount,
    required String description,
    required DateTime date,
  }) async {
    if (!mounted) return;
    final action = await showModalBottomSheet<String>(
      context: context,
      showDragHandle: true,
      builder: (context) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 20),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Text(type == 'receipt' ? 'تم حفظ سند القبض بنجاح' : 'تم حفظ سند الصرف بنجاح', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 6),
            Text('رقم السند: $number'),
            const SizedBox(height: 16),
            ListTile(leading: const CircleAvatar(child: Icon(Icons.check)), title: const Text('حفظ فقط'), onTap: () => Navigator.pop(context, 'saved')),
            if (type == 'receipt')
              ListTile(leading: const CircleAvatar(child: Icon(Icons.message)), title: const Text('فتح واتساب والرسالة جاهزة'), onTap: () => Navigator.pop(context, 'whatsapp')),
            ListTile(leading: const CircleAvatar(child: Icon(Icons.picture_as_pdf)), title: const Text('معاينة / طباعة A4'), onTap: () => Navigator.pop(context, 'pdf')),
            ListTile(leading: const CircleAvatar(child: Icon(Icons.receipt)), title: const Text('طباعة حرارية 80 مم'), onTap: () => Navigator.pop(context, 'thermal')),
          ]),
        ),
      ),
    );

    if (action == null || action == 'saved') return;

    if (action == 'whatsapp') {
      final phone = '${patient['phone'] ?? ''}'.trim();
      if (phone.isEmpty) {
        _message('لا يوجد رقم هاتف مسجل لهذا المريض.');
        return;
      }
      final center = await SettingsService.instance.centerName();
      final message = MessagingService.receiptMessage(
        patient: '${patient['full_name'] ?? ''}',
        center: center,
        receiptNo: number,
        amount: money(amount),
        date: _date.format(date),
        description: description.isEmpty ? 'سند قبض' : description,
        support: await SettingsService.instance.supportPhone(),
      );
      final ok = await MessagingService.whatsapp(phone, message);
      if (!ok) _message('تعذر فتح واتساب.');
      return;
    }

    await _printDocument(
      type: type,
      number: number,
      patient: patient,
      amount: amount,
      description: description,
      date: date,
      thermal: action == 'thermal',
    );
  }

  Future<void> _printDocument({
    required String type,
    required String number,
    required Map<String, Object?> patient,
    required double amount,
    required String description,
    required DateTime date,
    required bool thermal,
  }) async {
    try {
      final doc = pw.Document();
      final font = await PdfGoogleFonts.notoSansArabicRegular();
      final bold = await PdfGoogleFonts.notoSansArabicBold();
      final pageFormat = thermal
          ? PdfPageFormat(80 * PdfPageFormat.mm, 220 * PdfPageFormat.mm, marginAll: 5 * PdfPageFormat.mm)
          : PdfPageFormat.a4;

      doc.addPage(
        pw.Page(
          pageFormat: pageFormat,
          theme: pw.ThemeData.withFont(base: font, bold: bold),
          build: (_) => pw.Directionality(
            textDirection: pw.TextDirection.rtl,
            child: pw.Column(crossAxisAlignment: pw.CrossAxisAlignment.stretch, children: [
              pw.Center(child: pw.Text('مركز وسيم الطبي', style: pw.TextStyle(font: bold, fontSize: thermal ? 15 : 22))),
              pw.SizedBox(height: 4),
              pw.Center(child: pw.Text(type == 'receipt' ? 'سند قبض' : 'سند صرف', style: pw.TextStyle(font: bold, fontSize: thermal ? 13 : 18))),
              pw.SizedBox(height: 8),
              pw.Divider(),
              _pdfRow('رقم السند', number, font, bold),
              _pdfRow('التاريخ', _date.format(date), font, bold),
              if (type == 'receipt') _pdfRow('المريض', '${patient['full_name'] ?? ''}', font, bold),
              if (type == 'receipt') _pdfRow('رقم الملف', '${patient['file_no'] ?? ''}', font, bold),
              if (type == 'expense') _pdfRow('الحساب', '${patient['category'] ?? ''}', font, bold),
              _pdfRow('المبلغ', '${money(amount)} ريال', font, bold),
              _pdfRow('البيان', description.isEmpty ? (type == 'receipt' ? 'سند قبض' : 'سند صرف') : description, font, bold),
              pw.SizedBox(height: 14),
              pw.Divider(),
              pw.Center(child: pw.Text('نظام وسيم الطبي PRO', style: pw.TextStyle(font: font, fontSize: thermal ? 8 : 10))),
            ]),
          ),
        ),
      );

      await Printing.layoutPdf(onLayout: (_) async => doc.save());
    } catch (e) {
      _message('تعذر إنشاء المستند: $e');
    }
  }

  pw.Widget _pdfRow(String label, String value, pw.Font font, pw.Font bold) {
    return pw.Container(
      padding: const pw.EdgeInsets.symmetric(vertical: 6, horizontal: 8),
      margin: const pw.EdgeInsets.only(bottom: 4),
      decoration: const pw.BoxDecoration(color: PdfColors.grey100),
      child: pw.Row(crossAxisAlignment: pw.CrossAxisAlignment.start, children: [
        pw.SizedBox(width: 90, child: pw.Text('$label:', style: pw.TextStyle(font: bold, fontSize: 10))),
        pw.SizedBox(width: 8),
        pw.Expanded(child: pw.Text(value, style: pw.TextStyle(font: font, fontSize: 10))),
      ]),
    );
  }

  void _message(String text) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text)));
  }

  @override
  Widget build(BuildContext context) {
    final netToday = receipts - expenses;
    return Scaffold(
      appBar: AppBar(title: const Text('الإدارة المالية'), actions: [IconButton(onPressed: load, icon: const Icon(Icons.refresh))]),
      floatingActionButton: PopupMenuButton<String>(
        tooltip: 'عملية مالية جديدة',
        onSelected: (value) => value == 'receipt' ? receipt() : expense(),
        itemBuilder: (_) => const [
          PopupMenuItem(value: 'receipt', child: Text('سند قبض')),
          PopupMenuItem(value: 'expense', child: Text('سند صرف')),
        ],
        child: const FloatingActionButton.extended(onPressed: null, icon: Icon(Icons.add), label: Text('عملية مالية')),
      ),
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : RefreshIndicator(
              onRefresh: load,
              child: ListView(padding: const EdgeInsets.all(14), children: [
                GridView.count(
                  crossAxisCount: 2,
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  crossAxisSpacing: 10,
                  mainAxisSpacing: 10,
                  childAspectRatio: 1.55,
                  children: [
                    _stat('مقبوضات اليوم', money(receipts), Icons.arrow_downward, Colors.teal),
                    _stat('مصروفات اليوم', money(expenses), Icons.arrow_upward, Colors.redAccent),
                    _stat('صافي اليوم', money(netToday), Icons.account_balance_wallet, Colors.blue),
                    _stat('رصيد الصندوق', money(cashBalance), Icons.account_balance, Colors.indigo),
                  ],
                ),
                const SizedBox(height: 10),
                Card(elevation: 0, child: ListTile(leading: const Icon(Icons.people_alt_outlined), title: const Text('ذمم المرضى والعملاء'), trailing: Text(money(receivables))),),
                const SizedBox(height: 16),
                Row(children: [const Expanded(child: Text('آخر سندات القبض', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold))), TextButton.icon(onPressed: receipt, icon: const Icon(Icons.add), label: const Text('قبض'))]),
                if (recentReceipts.isEmpty) const Card(elevation: 0, child: ListTile(title: Text('لا توجد سندات قبض بعد.'))),
                ...recentReceipts.map((row) => Card(elevation: 0, child: ListTile(
                  leading: const CircleAvatar(child: Icon(Icons.receipt_long)),
                  title: Text('${row['receipt_no']} — ${row['full_name'] ?? 'غير محدد'}'),
                  subtitle: Text('${row['description'] ?? 'سند قبض'}\n${row['receipt_date'] ?? ''}'),
                  isThreeLine: true,
                  trailing: Text(money((row['amount'] as num?) ?? 0)),
                ))),
                const SizedBox(height: 12),
                Row(children: [const Expanded(child: Text('آخر سندات الصرف', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold))), TextButton.icon(onPressed: expense, icon: const Icon(Icons.add), label: const Text('صرف'))]),
                if (recentExpenses.isEmpty) const Card(elevation: 0, child: ListTile(title: Text('لا توجد سندات صرف بعد.'))),
                ...recentExpenses.map((row) => Card(elevation: 0, child: ListTile(
                  leading: const CircleAvatar(child: Icon(Icons.money_off)),
                  title: Text('${row['expense_no']} — ${row['category']}'),
                  subtitle: Text('${row['description'] ?? 'سند صرف'}\n${row['expense_date'] ?? ''}'),
                  isThreeLine: true,
                  trailing: Text(money((row['amount'] as num?) ?? 0)),
                ))),
              ]),
            ),
    );
  }

  Widget _stat(String title, String value, IconData icon, Color color) {
    return Card(elevation: 0, child: Padding(padding: const EdgeInsets.all(14), child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [Icon(icon, color: color, size: 28), const SizedBox(height: 7), Text(value, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 19)), Text(title, textAlign: TextAlign.center, style: const TextStyle(fontSize: 12))])));
  }
}
