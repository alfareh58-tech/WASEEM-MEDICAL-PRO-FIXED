import 'package:flutter/material.dart';
import '../services/settings_service.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});
  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  final center = TextEditingController();
  final support = TextEditingController();
  bool loading = true;

  @override
  void initState() { super.initState(); load(); }
  @override
  void dispose() { center.dispose(); support.dispose(); super.dispose(); }

  Future<void> load() async {
    center.text = await SettingsService.instance.centerName();
    support.text = await SettingsService.instance.supportPhone();
    if (mounted) setState(() => loading = false);
  }

  Future<void> save() async {
    await SettingsService.instance.setCenterName(center.text.trim().isEmpty ? 'وسيم ميديكال' : center.text.trim());
    await SettingsService.instance.setSupportPhone(support.text.trim());
    if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تم حفظ الإعدادات بنجاح.')));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(appBar: AppBar(title: const Text('الإعدادات')), body: loading ? const Center(child: CircularProgressIndicator()) : ListView(padding: const EdgeInsets.all(14), children: [
      Card(elevation: 0, child: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        const Text('بيانات المركز', style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold)), const SizedBox(height: 12),
        TextField(controller: center, decoration: const InputDecoration(labelText: 'اسم المركز', prefixIcon: Icon(Icons.business))), const SizedBox(height: 10),
        TextField(controller: support, keyboardType: TextInputType.phone, decoration: const InputDecoration(labelText: 'رقم الدعم والتواصل', prefixIcon: Icon(Icons.phone))), const SizedBox(height: 14),
        FilledButton.icon(onPressed: save, icon: const Icon(Icons.save), label: const Text('حفظ الإعدادات')),
      ]))),
      const SizedBox(height: 12),
      const Card(elevation: 0, child: ListTile(leading: Icon(Icons.info_outline), title: Text('اسم النظام'), subtitle: Text('وسيم ميديكال — WASEEM MEDICAL PRO'))),
      const Card(elevation: 0, child: ListTile(leading: Icon(Icons.storage_outlined), title: Text('التخزين'), subtitle: Text('قاعدة بيانات محلية داخل الجهاز، مع دعم الويب.'))),
    ]));
  }
}
