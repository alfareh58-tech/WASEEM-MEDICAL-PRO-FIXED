import 'package:flutter/material.dart';
import '../services/database_service.dart';
import '../services/settings_service.dart';
import '../widgets/stat_card.dart';
import 'add_patient_screen.dart';
import 'appointments_screen.dart';
import 'departments_screen.dart';
import 'finance_screen.dart';
import 'patients_screen.dart';
import 'reports_screen.dart';
import 'sessions_screen.dart';
import 'staff_screen.dart';

class HomeScreen extends StatefulWidget {
  final VoidCallback onThemeChanged;
  const HomeScreen({super.key, required this.onThemeChanged});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int patients = 0;
  int appointments = 0;
  int sessions = 0;
  double receipts = 0;
  double expenses = 0;
  String center = 'وسيم ميديكال';
  bool loading = true;

  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    try {
      final values = await Future.wait<dynamic>([
        DatabaseService.instance.patientCount(),
        DatabaseService.instance.todayAppointments(),
        DatabaseService.instance.todaySessions(),
        DatabaseService.instance.todayReceipts(),
        DatabaseService.instance.todayExpenses(),
        SettingsService.instance.centerName(),
      ]);
      if (!mounted) return;
      setState(() {
        patients = values[0] as int;
        appointments = values[1] as int;
        sessions = values[2] as int;
        receipts = values[3] as double;
        expenses = values[4] as double;
        center = values[5] as String;
        loading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() => loading = false);
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('تعذر تحميل لوحة التحكم: $e')));
    }
  }

  void open(Widget page) {
    Navigator.push(context, MaterialPageRoute(builder: (_) => page)).then((_) => load());
  }

  @override
  Widget build(BuildContext context) {
    return RefreshIndicator(
      onRefresh: load,
      child: ListView(
        padding: const EdgeInsets.fromLTRB(14, 12, 14, 28),
        children: [
          Row(children: [
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('نظام وسيم الطبي PRO', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20)),
              Text(center, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 12)),
            ])),
            IconButton(onPressed: load, tooltip: 'تحديث', icon: const Icon(Icons.refresh)),
            IconButton(onPressed: widget.onThemeChanged, tooltip: 'الوضع الليلي', icon: const Icon(Icons.brightness_6_outlined)),
          ]),
          const SizedBox(height: 12),
          Container(
            padding: const EdgeInsets.all(18),
            decoration: BoxDecoration(borderRadius: BorderRadius.circular(24), gradient: const LinearGradient(colors: [Color(0xFFE4F6F8), Color(0xFFF7FCFD)])),
            child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('إدارة المركز من مكان واحد', style: TextStyle(fontSize: 21, fontWeight: FontWeight.bold)),
              SizedBox(height: 6),
              Text('المرضى والمواعيد والجلسات والمالية والتقارير في نظام واحد.'),
            ]),
          ),
          const SizedBox(height: 14),
          if (loading) const LinearProgressIndicator(minHeight: 3),
          const SizedBox(height: 10),
          GridView.count(
            crossAxisCount: 2,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            crossAxisSpacing: 10,
            mainAxisSpacing: 10,
            childAspectRatio: 1.55,
            children: [
              StatCard(title: 'إجمالي المرضى', value: '$patients', icon: Icons.people, color: Colors.teal),
              StatCard(title: 'مواعيد اليوم', value: '$appointments', icon: Icons.calendar_month, color: Colors.blue),
              StatCard(title: 'جلسات اليوم', value: '$sessions', icon: Icons.healing, color: Colors.indigo),
              StatCard(title: 'مقبوضات اليوم', value: receipts.toStringAsFixed(0), icon: Icons.payments, color: Colors.amber.shade800),
            ],
          ),
          const SizedBox(height: 10),
          Card(elevation: 0, child: ListTile(
            leading: Icon(expenses > receipts ? Icons.warning_amber : Icons.account_balance_wallet_outlined),
            title: const Text('ملخص اليوم'),
            subtitle: Text('المقبوضات: ${receipts.toStringAsFixed(2)}  •  المصروفات: ${expenses.toStringAsFixed(2)}  •  الصافي: ${(receipts - expenses).toStringAsFixed(2)}'),
          )),
          const SizedBox(height: 14),
          const Text('الوصول السريع', style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold)),
          const SizedBox(height: 10),
          GridView.count(
            crossAxisCount: 2,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            crossAxisSpacing: 10,
            mainAxisSpacing: 10,
            childAspectRatio: 1.4,
            children: [
              _action('تسجيل مريض', Icons.person_add, const Color(0xFF0A9A86), () => open(const AddPatientScreen())),
              _action('المرضى', Icons.folder_shared, Colors.cyan.shade800, () => open(const PatientsScreen())),
              _action('المواعيد', Icons.calendar_month, const Color(0xFF1675B8), () => open(const AppointmentsScreen())),
              _action('الجلسات والباقات', Icons.healing, Colors.deepPurple, () => open(const SessionsScreen())),
              _action('الإدارة المالية', Icons.account_balance_wallet, Colors.blueGrey, () => open(const FinanceScreen())),
              _action('الأقسام والخدمات', Icons.medical_services, Colors.brown, () => open(const DepartmentsScreen())),
              _action('الموظفون', Icons.groups, Colors.indigo, () => open(const StaffScreen())),
              _action('التقارير', Icons.bar_chart, Colors.teal, () => open(const ReportsScreen())),
            ],
          ),
        ],
      ),
    );
  }

  Widget _action(String title, IconData icon, Color color, VoidCallback onTap) {
    return InkWell(
      borderRadius: BorderRadius.circular(18),
      onTap: onTap,
      child: Container(
        decoration: BoxDecoration(color: color, borderRadius: BorderRadius.circular(18)),
        padding: const EdgeInsets.all(14),
        child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
          Icon(icon, color: Colors.white, size: 32),
          const SizedBox(height: 8),
          Text(title, textAlign: TextAlign.center, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
        ]),
      ),
    );
  }
}
