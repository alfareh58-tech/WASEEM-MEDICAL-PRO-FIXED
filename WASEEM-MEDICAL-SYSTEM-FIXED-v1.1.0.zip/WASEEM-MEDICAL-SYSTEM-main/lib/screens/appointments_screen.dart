import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../services/database_service.dart';

class AppointmentsScreen extends StatefulWidget {
  const AppointmentsScreen({super.key});
  @override
  State<AppointmentsScreen> createState() => _AppointmentsScreenState();
}

class _AppointmentsScreenState extends State<AppointmentsScreen> {
  List<Map<String, Object?>> rows = [];
  bool loading = true;
  final dateFormat = DateFormat('yyyy/MM/dd HH:mm', 'ar');

  @override
  void initState() { super.initState(); load(); }

  Future<void> load() async {
    setState(() => loading = true);
    try {
      final data = await DatabaseService.instance.appointments();
      if (!mounted) return;
      setState(() { rows = data; loading = false; });
    } catch (e) {
      if (!mounted) return;
      setState(() => loading = false);
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('تعذر تحميل المواعيد: $e')));
    }
  }

  Future<void> add() async {
    final patients = await DatabaseService.instance.patients();
    if (patients.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('أضف مريضًا أولًا.')));
      return;
    }
    int patientId = (patients.first['id'] as num).toInt();
    DateTime date = DateTime.now().add(const Duration(hours: 1));
    final doctor = TextEditingController();
    final service = TextEditingController();
    final notes = TextEditingController();

    final ok = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => StatefulBuilder(builder: (context, setDialogState) => AlertDialog(
        title: const Text('حجز موعد جديد'),
        content: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, children: [
          DropdownButtonFormField<int>(
            value: patientId,
            isExpanded: true,
            items: [for (final p in patients) DropdownMenuItem(value: (p['id'] as num).toInt(), child: Text('${p['file_no']} — ${p['full_name']}', overflow: TextOverflow.ellipsis))],
            onChanged: (v) => setDialogState(() => patientId = v ?? patientId),
            decoration: const InputDecoration(labelText: 'المريض', prefixIcon: Icon(Icons.person)),
          ),
          const SizedBox(height: 10),
          ListTile(
            contentPadding: EdgeInsets.zero,
            leading: const Icon(Icons.calendar_month),
            title: const Text('التاريخ والوقت'),
            subtitle: Text(dateFormat.format(date)),
            onTap: () async {
              final d = await showDatePicker(context: context, firstDate: DateTime.now(), lastDate: DateTime.now().add(const Duration(days: 365)), initialDate: date);
              if (d == null || !context.mounted) return;
              final t = await showTimePicker(context: context, initialTime: TimeOfDay.fromDateTime(date));
              if (t != null) setDialogState(() => date = DateTime(d.year, d.month, d.day, t.hour, t.minute));
            },
          ),
          TextField(controller: doctor, decoration: const InputDecoration(labelText: 'الطبيب / الأخصائي')),
          const SizedBox(height: 10),
          TextField(controller: service, decoration: const InputDecoration(labelText: 'الخدمة')),
          const SizedBox(height: 10),
          TextField(controller: notes, maxLines: 2, decoration: const InputDecoration(labelText: 'ملاحظات')),
        ])),
        actions: [
          TextButton(onPressed: () => Navigator.pop(dialogContext, false), child: const Text('إلغاء')),
          FilledButton(onPressed: () => Navigator.pop(dialogContext, true), child: const Text('حفظ الموعد')),
        ],
      )),
    );

    if (ok == true) {
      try {
        final patient = patients.firstWhere((p) => (p['id'] as num).toInt() == patientId);
        await DatabaseService.instance.db.insert('appointments', {
          'patient_id': patientId,
          'doctor': doctor.text.trim(),
          'department': patient['department'] ?? '',
          'service': service.text.trim(),
          'appointment_date': date.toIso8601String(),
          'status': 'مجدول',
          'notes': notes.text.trim(),
        });
        await DatabaseService.instance.addAudit('حجز موعد', '${patient['file_no']}');
        await load();
      } catch (e) {
        if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('تعذر حفظ الموعد: $e')));
      }
    }
    doctor.dispose(); service.dispose(); notes.dispose();
  }

  Future<void> updateStatus(int id, String status) async {
    await DatabaseService.instance.db.update('appointments', {'status': status}, where: 'id=?', whereArgs: [id]);
    await load();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('المواعيد'), actions: [IconButton(onPressed: load, icon: const Icon(Icons.refresh))]),
      floatingActionButton: FloatingActionButton.extended(onPressed: add, icon: const Icon(Icons.add), label: const Text('موعد جديد')),
      body: loading ? const Center(child: CircularProgressIndicator()) : RefreshIndicator(
        onRefresh: load,
        child: rows.isEmpty
            ? ListView(children: const [SizedBox(height: 220), Center(child: Text('لا توجد مواعيد مسجلة.'))])
            : ListView.builder(
                padding: const EdgeInsets.all(12),
                itemCount: rows.length,
                itemBuilder: (_, i) {
                  final row = rows[i];
                  return Card(elevation: 0, child: ListTile(
                    leading: const CircleAvatar(child: Icon(Icons.calendar_month)),
                    title: Text('${row['full_name'] ?? ''}'),
                    subtitle: Text('${row['appointment_date'] ?? ''}\n${row['doctor'] ?? ''} • ${row['service'] ?? ''}'),
                    isThreeLine: true,
                    trailing: PopupMenuButton<String>(
                      initialValue: null,
                      onSelected: (value) => updateStatus((row['id'] as num).toInt(), value),
                      itemBuilder: (_) => const [
                        PopupMenuItem(value: 'مجدول', child: Text('مجدول')),
                        PopupMenuItem(value: 'حضر', child: Text('حضر')),
                        PopupMenuItem(value: 'مكتمل', child: Text('مكتمل')),
                        PopupMenuItem(value: 'ملغى', child: Text('ملغى')),
                      ],
                      child: Chip(label: Text('${row['status']}')),
                    ),
                  ));
                },
              ),
      ),
    );
  }
}
