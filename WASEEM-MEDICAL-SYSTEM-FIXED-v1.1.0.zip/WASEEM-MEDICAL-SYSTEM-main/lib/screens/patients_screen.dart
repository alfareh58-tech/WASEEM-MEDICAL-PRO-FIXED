import 'dart:async';
import 'package:flutter/material.dart';
import '../services/database_service.dart';
import 'add_patient_screen.dart';
import 'patient_details_screen.dart';

class PatientsScreen extends StatefulWidget {
  const PatientsScreen({super.key});
  @override
  State<PatientsScreen> createState() => _PatientsScreenState();
}

class _PatientsScreenState extends State<PatientsScreen> {
  final search = TextEditingController();
  Timer? _timer;
  List<Map<String, Object?>> rows = [];
  bool loading = true;

  @override
  void initState() { super.initState(); search.addListener(_onSearch); load(); }
  @override
  void dispose() { _timer?.cancel(); search.dispose(); super.dispose(); }

  void _onSearch() {
    _timer?.cancel();
    _timer = Timer(const Duration(milliseconds: 250), load);
  }

  Future<void> load() async {
    try {
      final data = await DatabaseService.instance.patients(search: search.text);
      if (!mounted) return;
      setState(() { rows = data; loading = false; });
    } catch (e) {
      if (!mounted) return;
      setState(() => loading = false);
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('تعذر تحميل المرضى: $e')));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('ملفات المرضى'), actions: [IconButton(onPressed: load, icon: const Icon(Icons.refresh))]),
      floatingActionButton: FloatingActionButton.extended(onPressed: () async { await Navigator.push(context, MaterialPageRoute(builder: (_) => const AddPatientScreen())); load(); }, icon: const Icon(Icons.person_add), label: const Text('مريض جديد')),
      body: Column(children: [
        Padding(padding: const EdgeInsets.fromLTRB(12, 12, 12, 6), child: TextField(controller: search, textInputAction: TextInputAction.search, decoration: InputDecoration(hintText: 'ابحث بالاسم أو الهاتف أو رقم الملف أو الهوية', prefixIcon: const Icon(Icons.search), suffixIcon: search.text.isEmpty ? null : IconButton(onPressed: () { search.clear(); load(); }, icon: const Icon(Icons.clear))))),
        Expanded(child: loading ? const Center(child: CircularProgressIndicator()) : RefreshIndicator(onRefresh: load, child: rows.isEmpty ? ListView(children: const [SizedBox(height: 220), Center(child: Text('لا توجد نتائج.'))]) : ListView.builder(padding: const EdgeInsets.all(12), itemCount: rows.length, itemBuilder: (_, i) {
          final patient = rows[i];
          return Card(elevation: 0, child: ListTile(onTap: () async { await Navigator.push(context, MaterialPageRoute(builder: (_) => PatientDetailsScreen(patientId: (patient['id'] as num).toInt()))); load(); }, leading: const CircleAvatar(child: Icon(Icons.person)), title: Text('${patient['full_name']}'), subtitle: Text('${patient['file_no']} • ${patient['phone']}\n${patient['department'] ?? ''} • ${patient['service'] ?? ''}'), isThreeLine: true, trailing: const Icon(Icons.chevron_left)));
        }))),
      ]),
    );
  }
}
