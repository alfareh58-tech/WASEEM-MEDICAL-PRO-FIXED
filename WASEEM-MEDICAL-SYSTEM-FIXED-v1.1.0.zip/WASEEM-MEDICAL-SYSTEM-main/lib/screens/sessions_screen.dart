import 'package:flutter/material.dart';
import '../services/database_service.dart';

class SessionsScreen extends StatefulWidget {
  const SessionsScreen({super.key});
  @override
  State<SessionsScreen> createState() => _SessionsScreenState();
}

class _SessionsScreenState extends State<SessionsScreen> {
  List<Map<String, Object?>> sessions = [];
  List<Map<String, Object?>> packages = [];
  bool loading = true;

  @override
  void initState() { super.initState(); load(); }

  Future<void> load() async {
    setState(() => loading = true);
    try {
      final values = await Future.wait([
        DatabaseService.instance.sessions(),
        DatabaseService.instance.packages(),
      ]);
      if (!mounted) return;
      setState(() {
        sessions = (values[0] as List).cast<Map<String, Object?>>();
        packages = (values[1] as List).cast<Map<String, Object?>>();
        loading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() => loading = false);
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('تعذر تحميل الجلسات: $e')));
    }
  }

  Future<void> addSession() async {
    final patients = await DatabaseService.instance.patients();
    if (patients.isEmpty) { _message('أضف مريضًا أولًا.'); return; }
    int patientId = (patients.first['id'] as num).toInt();
    int? packageId;
    final therapist = TextEditingController();
    final type = TextEditingController(text: 'جلسة علاج طبيعي');
    final notes = TextEditingController();

    final ok = await showDialog<bool>(context: context, builder: (dialogContext) => StatefulBuilder(builder: (context, setDialogState) {
      final patientPackages = packages.where((p) => (p['patient_id'] as num).toInt() == patientId && '${p['status']}' == 'فعالة' && ((p['remaining_sessions'] as num?)?.toInt() ?? 0) > 0).toList();
      if (packageId != null && !patientPackages.any((p) => (p['id'] as num).toInt() == packageId)) packageId = null;
      return AlertDialog(
        title: const Text('تسجيل جلسة'),
        content: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, children: [
          DropdownButtonFormField<int>(value: patientId, isExpanded: true, items: [for (final p in patients) DropdownMenuItem(value: (p['id'] as num).toInt(), child: Text('${p['file_no']} — ${p['full_name']}', overflow: TextOverflow.ellipsis))], onChanged: (v) => setDialogState(() { patientId = v ?? patientId; packageId = null; }), decoration: const InputDecoration(labelText: 'المريض')),
          const SizedBox(height: 10),
          DropdownButtonFormField<int?>(value: packageId, isExpanded: true, items: [const DropdownMenuItem<int?>(value: null, child: Text('بدون باقة')), ...patientPackages.map((p) => DropdownMenuItem<int?>(value: (p['id'] as num).toInt(), child: Text('${p['name']} — متبقي ${p['remaining_sessions']}')))], onChanged: (v) => setDialogState(() => packageId = v), decoration: const InputDecoration(labelText: 'الباقة')),
          const SizedBox(height: 10),
          TextField(controller: type, decoration: const InputDecoration(labelText: 'نوع الجلسة')),
          const SizedBox(height: 10),
          TextField(controller: therapist, decoration: const InputDecoration(labelText: 'المعالج / الأخصائي')),
          const SizedBox(height: 10),
          TextField(controller: notes, maxLines: 2, decoration: const InputDecoration(labelText: 'ملاحظات')),
        ])),
        actions: [TextButton(onPressed: () => Navigator.pop(dialogContext, false), child: const Text('إلغاء')), FilledButton(onPressed: () => Navigator.pop(dialogContext, true), child: const Text('حفظ'))],
      );
    }));

    if (ok == true) {
      try {
        await DatabaseService.instance.db.insert('sessions', {
          'patient_id': patientId,
          'package_id': packageId,
          'therapist': therapist.text.trim(),
          'session_type': type.text.trim().isEmpty ? 'جلسة علاجية' : type.text.trim(),
          'start_time': DateTime.now().toIso8601String(),
          'status': 'مجدولة',
          'notes': notes.text.trim(),
        });
        await load();
      } catch (e) { _message('تعذر حفظ الجلسة: $e'); }
    }
    therapist.dispose(); type.dispose(); notes.dispose();
  }

  Future<void> createPackage() async {
    final patients = await DatabaseService.instance.patients();
    if (patients.isEmpty) { _message('أضف مريضًا أولًا.'); return; }
    int patientId = (patients.first['id'] as num).toInt();
    final name = TextEditingController(text: 'باقة علاج طبيعي');
    final service = TextEditingController(text: 'العلاج الطبيعي');
    final total = TextEditingController(text: '10');
    final price = TextEditingController();
    DateTime endDate = DateTime.now().add(const Duration(days: 60));

    final ok = await showDialog<bool>(context: context, builder: (dialogContext) => StatefulBuilder(builder: (context, setDialogState) => AlertDialog(
      title: const Text('إنشاء باقة جلسات'),
      content: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, children: [
        DropdownButtonFormField<int>(value: patientId, isExpanded: true, items: [for (final p in patients) DropdownMenuItem(value: (p['id'] as num).toInt(), child: Text('${p['file_no']} — ${p['full_name']}', overflow: TextOverflow.ellipsis))], onChanged: (v) => setDialogState(() => patientId = v ?? patientId), decoration: const InputDecoration(labelText: 'المريض')),
        const SizedBox(height: 10), TextField(controller: name, decoration: const InputDecoration(labelText: 'اسم الباقة')), const SizedBox(height: 10), TextField(controller: service, decoration: const InputDecoration(labelText: 'الخدمة')), const SizedBox(height: 10), TextField(controller: total, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'عدد الجلسات')), const SizedBox(height: 10), TextField(controller: price, keyboardType: const TextInputType.numberWithOptions(decimal: true), decoration: const InputDecoration(labelText: 'السعر')), const SizedBox(height: 4), ListTile(contentPadding: EdgeInsets.zero, title: const Text('تاريخ انتهاء الباقة'), subtitle: Text('${endDate.year}/${endDate.month.toString().padLeft(2, '0')}/${endDate.day.toString().padLeft(2, '0')}'), onTap: () async { final d = await showDatePicker(context: context, firstDate: DateTime.now(), lastDate: DateTime.now().add(const Duration(days: 730)), initialDate: endDate); if (d != null) setDialogState(() => endDate = d); }),
      ])),
      actions: [TextButton(onPressed: () => Navigator.pop(dialogContext, false), child: const Text('إلغاء')), FilledButton(onPressed: () => Navigator.pop(dialogContext, true), child: const Text('حفظ'))],
    )));

    if (ok == true) {
      final n = int.tryParse(total.text.trim()) ?? 0;
      if (n <= 0) { _message('عدد الجلسات يجب أن يكون أكبر من صفر.'); } else {
        await DatabaseService.instance.db.insert('packages', {'patient_id': patientId, 'name': name.text.trim().isEmpty ? 'باقة علاجية' : name.text.trim(), 'service': service.text.trim(), 'total_sessions': n, 'remaining_sessions': n, 'price': double.tryParse(price.text.trim()) ?? 0, 'start_date': DateTime.now().toIso8601String(), 'end_date': endDate.toIso8601String(), 'status': 'فعالة'});
        await load();
      }
    }
    name.dispose(); service.dispose(); total.dispose(); price.dispose();
  }

  Future<void> _complete(int id) async { try { await DatabaseService.instance.completeSession(id); await load(); } catch (e) { _message('$e'); } }
  Future<void> _cancel(int id) async { try { await DatabaseService.instance.cancelSession(id); await load(); } catch (e) { _message('$e'); } }
  void _message(String text) { if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text))); }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('الجلسات والباقات'), actions: [IconButton(onPressed: createPackage, tooltip: 'باقة جديدة', icon: const Icon(Icons.card_membership)), IconButton(onPressed: load, icon: const Icon(Icons.refresh))]),
      floatingActionButton: FloatingActionButton.extended(onPressed: addSession, icon: const Icon(Icons.add), label: const Text('جلسة')),
      body: loading ? const Center(child: CircularProgressIndicator()) : RefreshIndicator(onRefresh: load, child: ListView(padding: const EdgeInsets.all(12), children: [
        const Text('الباقات', style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold)),
        if (packages.isEmpty) const Card(elevation: 0, child: ListTile(title: Text('لا توجد باقات.'))),
        ...packages.map((p) => Card(elevation: 0, child: ListTile(leading: const Icon(Icons.card_membership), title: Text('${p['name']} — ${p['full_name']}'), subtitle: Text('الخدمة: ${p['service'] ?? ''}\nالمتبقي: ${p['remaining_sessions']} من ${p['total_sessions']}'), isThreeLine: true, trailing: Text('${p['price']}')))),
        const SizedBox(height: 18),
        const Text('الجلسات', style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold)),
        if (sessions.isEmpty) const Card(elevation: 0, child: ListTile(title: Text('لا توجد جلسات.'))),
        ...sessions.map((s) => Card(elevation: 0, child: ListTile(leading: const Icon(Icons.healing), title: Text('${s['full_name']}'), subtitle: Text('${s['session_type']} • ${s['therapist'] ?? ''}\n${s['status']}'), isThreeLine: true, trailing: PopupMenuButton<String>(onSelected: (v) => v == 'complete' ? _complete((s['id'] as num).toInt()) : _cancel((s['id'] as num).toInt()), itemBuilder: (_) => const [PopupMenuItem(value: 'complete', child: Text('تسجيل مكتملة وخصم الجلسة')), PopupMenuItem(value: 'cancel', child: Text('إلغاء الجلسة'))])))),
      ])),
    );
  }
}
