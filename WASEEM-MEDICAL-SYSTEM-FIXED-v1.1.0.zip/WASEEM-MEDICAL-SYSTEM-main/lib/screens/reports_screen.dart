import 'package:flutter/material.dart';
import '../services/database_service.dart';

class ReportsScreen extends StatefulWidget {
  const ReportsScreen({super.key});
  @override
  State<ReportsScreen> createState() => _ReportsScreenState();
}

class _ReportsScreenState extends State<ReportsScreen> {
  Map<String, double> balance = {};
  double cash = 0;
  double receivables = 0;
  double receipts = 0;
  double expenses = 0;
  bool loading = true;

  @override
  void initState() { super.initState(); load(); }

  Future<void> load() async {
    setState(() => loading = true);
    try {
      final values = await Future.wait<dynamic>([
        DatabaseService.instance.trialBalance(),
        DatabaseService.instance.cashBalance(),
        DatabaseService.instance.receivablesBalance(),
        DatabaseService.instance.todayReceipts(),
        DatabaseService.instance.todayExpenses(),
      ]);
      if (!mounted) return;
      setState(() { balance = values[0] as Map<String, double>; cash = values[1] as double; receivables = values[2] as double; receipts = values[3] as double; expenses = values[4] as double; loading = false; });
    } catch (e) { if (!mounted) return; setState(() => loading = false); ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('تعذر تحميل التقارير: $e'))); }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(appBar: AppBar(title: const Text('التقارير والإحصائيات'), actions: [IconButton(onPressed: load, icon: const Icon(Icons.refresh))]), body: loading ? const Center(child: CircularProgressIndicator()) : RefreshIndicator(onRefresh: load, child: ListView(padding: const EdgeInsets.all(14), children: [
      const Text('ملخص مالي', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
      Card(elevation: 0, child: Column(children: [ListTile(leading: const Icon(Icons.account_balance_wallet), title: const Text('رصيد الصندوق'), trailing: Text(cash.toStringAsFixed(2))), ListTile(leading: const Icon(Icons.people_alt), title: const Text('ذمم المرضى والعملاء'), trailing: Text(receivables.toStringAsFixed(2))), ListTile(leading: const Icon(Icons.arrow_downward), title: const Text('مقبوضات اليوم'), trailing: Text(receipts.toStringAsFixed(2))), ListTile(leading: const Icon(Icons.arrow_upward), title: const Text('مصروفات اليوم'), trailing: Text(expenses.toStringAsFixed(2)))])),
      const SizedBox(height: 18),
      Row(children: [const Expanded(child: Text('ميزان المراجعة', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold))), TextButton.icon(onPressed: load, icon: const Icon(Icons.refresh), label: const Text('تحديث'))]),
      Card(elevation: 0, child: balance.isEmpty ? const ListTile(title: Text('لا توجد قيود محاسبية بعد.')) : Column(children: balance.entries.map((entry) => ListTile(title: Text(entry.key), trailing: Text(entry.value.toStringAsFixed(2)))).toList())),
    ])));
  }
}
