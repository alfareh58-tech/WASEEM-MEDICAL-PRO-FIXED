import 'package:flutter/material.dart';
import '../services/database_service.dart';

class StaffScreen extends StatefulWidget {
  const StaffScreen({super.key});
  @override
  State<StaffScreen> createState() => _StaffScreenState();
}

class _StaffScreenState extends State<StaffScreen> {
  List<Map<String, Object?>> rows = [];
  bool loading = true;

  @override
  void initState() { super.initState(); load(); }

  Future<void> load() async {
    setState(() => loading = true);
    try {
      final data = await DatabaseService.instance.staff();
      if (!mounted) return;
      setState(() { rows = data; loading = false; });
    } catch (e) {
      if (!mounted) return;
      setState(() => loading = false);
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('تعذر تحميل الكادر: $e')));
    }
  }

  Future<void> add() async {
    final name = TextEditingController();
    final phone = TextEditingController();
    final job = TextEditingController(text: 'موظف');
    final salary = TextEditingController();
    final department = TextEditingController();
    final ok = await showDialog<bool>(context: context, builder: (dialogContext) => AlertDialog(
      title: const Text('إضافة كادر / موظف'),
      content: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, children: [
        TextField(controller: name, decoration: const InputDecoration(labelText: 'الاسم الكامل *')),
        const SizedBox(height: 10), TextField(controller: phone, keyboardType: TextInputType.phone, decoration: const InputDecoration(labelText: 'رقم الهاتف *')),
        const SizedBox(height: 10), TextField(controller: job, decoration: const InputDecoration(labelText: 'المسمى الوظيفي')),
        const SizedBox(height: 10), TextField(controller: department, decoration: const InputDecoration(labelText: 'القسم')),
        const SizedBox(height: 10), TextField(controller: salary, keyboardType: const TextInputType.numberWithOptions(decimal: true), decoration: const InputDecoration(labelText: 'الراتب الأساسي')),
      ])),
      actions: [TextButton(onPressed: () => Navigator.pop(dialogContext, false), child: const Text('إلغاء')), FilledButton(onPressed: () => Navigator.pop(dialogContext, true), child: const Text('حفظ'))],
    ));
    if (ok == true) {
      if (name.text.trim().isEmpty || phone.text.trim().isEmpty) { _message('الاسم ورقم الهاتف مطلوبان.'); } else {
        try {
          await DatabaseService.instance.db.insert('staff', {'name': name.text.trim(), 'phone': phone.text.trim(), 'job_type': job.text.trim().isEmpty ? 'موظف' : job.text.trim(), 'department': department.text.trim(), 'salary': double.tryParse(salary.text.trim()) ?? 0, 'status': 'نشط'});
          await load();
        } catch (e) { _message('تعذر الحفظ: $e'); }
      }
    }
    name.dispose(); phone.dispose(); job.dispose(); salary.dispose(); department.dispose();
  }

  void _message(String text) { if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text))); }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('إدارة الكادر والموظفين'), actions: [IconButton(onPressed: load, icon: const Icon(Icons.refresh))]),
      floatingActionButton: FloatingActionButton.extended(onPressed: add, icon: const Icon(Icons.person_add), label: const Text('إضافة')),
      body: loading ? const Center(child: CircularProgressIndicator()) : RefreshIndicator(onRefresh: load, child: rows.isEmpty ? ListView(children: const [SizedBox(height: 220), Center(child: Text('لا يوجد كادر مسجل حاليًا.'))]) : ListView.builder(padding: const EdgeInsets.all(12), itemCount: rows.length, itemBuilder: (_, i) {
        final row = rows[i];
        return Card(elevation: 0, child: ListTile(leading: const CircleAvatar(child: Icon(Icons.person)), title: Text('${row['name'] ?? ''}'), subtitle: Text('${row['job_type'] ?? 'موظف'} • ${row['department'] ?? ''}\n${row['phone'] ?? ''}'), isThreeLine: true, trailing: Text('${row['salary'] ?? 0}')));
      })),
    );
  }
}
