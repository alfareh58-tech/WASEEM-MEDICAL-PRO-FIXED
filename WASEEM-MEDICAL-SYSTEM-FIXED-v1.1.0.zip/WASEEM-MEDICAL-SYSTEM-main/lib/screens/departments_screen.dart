import 'package:flutter/material.dart';
import '../services/database_service.dart';

class DepartmentsScreen extends StatefulWidget {
  const DepartmentsScreen({super.key});
  @override
  State<DepartmentsScreen> createState() => _DepartmentsScreenState();
}

class _DepartmentsScreenState extends State<DepartmentsScreen> {
  List<Map<String, Object?>> rows = [];
  bool loading = true;

  @override
  void initState() { super.initState(); load(); }

  Future<void> load() async {
    setState(() => loading = true);
    try {
      final data = await DatabaseService.instance.departments();
      if (!mounted) return;
      setState(() { rows = data; loading = false; });
    } catch (e) {
      if (!mounted) return;
      setState(() => loading = false);
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('تعذر تحميل الأقسام: $e')));
    }
  }

  Future<void> add() async {
    final name = TextEditingController();
    final responsible = TextEditingController();
    final days = TextEditingController();
    final ok = await showDialog<bool>(context: context, builder: (dialogContext) => AlertDialog(
      title: const Text('إضافة قسم'),
      content: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, children: [
        TextField(controller: name, decoration: const InputDecoration(labelText: 'اسم القسم *')),
        const SizedBox(height: 10),
        TextField(controller: responsible, decoration: const InputDecoration(labelText: 'المسؤول')),
        const SizedBox(height: 10),
        TextField(controller: days, decoration: const InputDecoration(labelText: 'أيام وساعات العمل')),
      ])),
      actions: [TextButton(onPressed: () => Navigator.pop(dialogContext, false), child: const Text('إلغاء')), FilledButton(onPressed: () => Navigator.pop(dialogContext, true), child: const Text('حفظ'))],
    ));
    if (ok == true && name.text.trim().isNotEmpty) {
      try {
        await DatabaseService.instance.db.insert('departments', {'name': name.text.trim(), 'responsible': responsible.text.trim(), 'work_days': days.text.trim(), 'active': 1});
        await load();
      } catch (e) { if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('تعذر حفظ القسم: $e'))); }
    }
    name.dispose(); responsible.dispose(); days.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('الأقسام والخدمات'), actions: [IconButton(onPressed: load, icon: const Icon(Icons.refresh))]),
      floatingActionButton: FloatingActionButton.extended(onPressed: add, icon: const Icon(Icons.add), label: const Text('قسم جديد')),
      body: loading ? const Center(child: CircularProgressIndicator()) : RefreshIndicator(onRefresh: load, child: rows.isEmpty ? ListView(children: const [SizedBox(height: 220), Center(child: Text('لا توجد أقسام.'))]) : ListView.builder(padding: const EdgeInsets.all(12), itemCount: rows.length, itemBuilder: (_, i) {
        final row = rows[i];
        return Card(elevation: 0, child: ListTile(leading: const CircleAvatar(child: Icon(Icons.local_hospital)), title: Text('${row['name']}'), subtitle: Text('${row['responsible'] ?? ''}\n${row['work_days'] ?? ''}'), isThreeLine: true));
      })),
    );
  }
}
