import 'package:flutter/foundation.dart';
import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';

class DatabaseService {
  DatabaseService._();
  static final instance = DatabaseService._();

  Database? _db;
  Database get db => _db!;

  Future<void> initialize() async {
    if (_db != null) return;

    final path = kIsWeb
        ? 'waseem_medical_pro_web.db'
        : join(await getDatabasesPath(), 'waseem_medical_pro.db');

    _db = await openDatabase(
      path,
      version: 2,
      onConfigure: (database) async {
        await database.execute('PRAGMA foreign_keys = ON');
      },
      onCreate: _onCreate,
      onUpgrade: _onUpgrade,
    );
  }

  Future<void> _onUpgrade(Database database, int oldVersion, int newVersion) async {
    if (oldVersion < 2) {
      await _createIndexes(database);
    }
  }

  Future<void> _onCreate(Database database, int version) async {
    await database.execute('''
      CREATE TABLE patients(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        file_no TEXT UNIQUE NOT NULL,
        full_name TEXT NOT NULL,
        phone TEXT NOT NULL,
        gender TEXT NOT NULL,
        age INTEGER,
        birth_date TEXT,
        address TEXT,
        national_id TEXT,
        department TEXT,
        service TEXT,
        doctor TEXT,
        referral_source TEXT,
        notes TEXT,
        status TEXT NOT NULL DEFAULT 'نشط',
        created_at TEXT NOT NULL
      )
    ''');

    await database.execute('''
      CREATE TABLE medical_records(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        patient_id INTEGER NOT NULL,
        diagnosis TEXT,
        complaint TEXT,
        treatment_plan TEXT,
        notes TEXT,
        created_at TEXT NOT NULL,
        FOREIGN KEY(patient_id) REFERENCES patients(id) ON DELETE CASCADE
      )
    ''');

    await database.execute('''
      CREATE TABLE appointments(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        patient_id INTEGER NOT NULL,
        doctor TEXT,
        department TEXT,
        service TEXT,
        appointment_date TEXT NOT NULL,
        status TEXT NOT NULL DEFAULT 'مجدول',
        notes TEXT,
        FOREIGN KEY(patient_id) REFERENCES patients(id) ON DELETE CASCADE
      )
    ''');

    await database.execute('''
      CREATE TABLE packages(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        patient_id INTEGER NOT NULL,
        name TEXT NOT NULL,
        service TEXT,
        total_sessions INTEGER NOT NULL,
        remaining_sessions INTEGER NOT NULL,
        price REAL NOT NULL DEFAULT 0,
        start_date TEXT NOT NULL,
        end_date TEXT NOT NULL,
        status TEXT NOT NULL DEFAULT 'فعالة',
        FOREIGN KEY(patient_id) REFERENCES patients(id) ON DELETE CASCADE
      )
    ''');

    await database.execute('''
      CREATE TABLE sessions(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        patient_id INTEGER NOT NULL,
        package_id INTEGER,
        therapist TEXT,
        session_type TEXT NOT NULL,
        start_time TEXT NOT NULL,
        end_time TEXT,
        status TEXT NOT NULL DEFAULT 'مجدولة',
        notes TEXT,
        rating INTEGER,
        session_transaction_id TEXT UNIQUE,
        FOREIGN KEY(patient_id) REFERENCES patients(id) ON DELETE CASCADE,
        FOREIGN KEY(package_id) REFERENCES packages(id) ON DELETE SET NULL
      )
    ''');

    await database.execute('''
      CREATE TABLE accounts(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        code TEXT UNIQUE NOT NULL,
        name TEXT UNIQUE NOT NULL,
        type TEXT NOT NULL,
        parent_code TEXT,
        active INTEGER NOT NULL DEFAULT 1
      )
    ''');

    await database.execute('''
      CREATE TABLE journal_entries(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        entry_no TEXT UNIQUE NOT NULL,
        entry_date TEXT NOT NULL,
        description TEXT,
        reference_type TEXT,
        reference_id INTEGER,
        created_at TEXT NOT NULL
      )
    ''');

    await database.execute('''
      CREATE TABLE journal_lines(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        journal_id INTEGER NOT NULL,
        account_id INTEGER NOT NULL,
        debit REAL NOT NULL DEFAULT 0,
        credit REAL NOT NULL DEFAULT 0,
        description TEXT,
        FOREIGN KEY(journal_id) REFERENCES journal_entries(id) ON DELETE CASCADE,
        FOREIGN KEY(account_id) REFERENCES accounts(id)
      )
    ''');

    await database.execute('''
      CREATE TABLE invoices(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        invoice_no TEXT UNIQUE NOT NULL,
        patient_id INTEGER NOT NULL,
        invoice_date TEXT NOT NULL,
        total REAL NOT NULL,
        paid REAL NOT NULL DEFAULT 0,
        payment_method TEXT NOT NULL DEFAULT 'آجل',
        status TEXT NOT NULL DEFAULT 'غير مدفوعة',
        notes TEXT,
        FOREIGN KEY(patient_id) REFERENCES patients(id) ON DELETE CASCADE
      )
    ''');

    await database.execute('''
      CREATE TABLE receipts(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        receipt_no TEXT UNIQUE NOT NULL,
        patient_id INTEGER,
        receipt_date TEXT NOT NULL,
        amount REAL NOT NULL,
        account_name TEXT NOT NULL,
        description TEXT,
        FOREIGN KEY(patient_id) REFERENCES patients(id) ON DELETE SET NULL
      )
    ''');

    await database.execute('''
      CREATE TABLE expenses(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        expense_no TEXT UNIQUE NOT NULL,
        expense_date TEXT NOT NULL,
        category TEXT NOT NULL,
        amount REAL NOT NULL,
        description TEXT
      )
    ''');

    await database.execute('''
      CREATE TABLE departments(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT UNIQUE NOT NULL,
        responsible TEXT,
        work_days TEXT,
        active INTEGER NOT NULL DEFAULT 1
      )
    ''');

    await database.execute('''
      CREATE TABLE services(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        department_id INTEGER NOT NULL,
        name TEXT NOT NULL,
        price REAL NOT NULL DEFAULT 0,
        duration INTEGER NOT NULL DEFAULT 30,
        package_allowed INTEGER NOT NULL DEFAULT 1,
        active INTEGER NOT NULL DEFAULT 1,
        FOREIGN KEY(department_id) REFERENCES departments(id) ON DELETE CASCADE
      )
    ''');

    await database.execute('''
      CREATE TABLE staff(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        phone TEXT NOT NULL,
        national_id TEXT,
        job_type TEXT NOT NULL,
        department TEXT,
        hire_date TEXT,
        contract_type TEXT,
        status TEXT NOT NULL DEFAULT 'نشط',
        salary REAL NOT NULL DEFAULT 0
      )
    ''');

    await database.execute('''
      CREATE TABLE audit_log(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        action TEXT NOT NULL,
        reference TEXT,
        created_at TEXT NOT NULL
      )
    ''');

    await _seed(database);
    await _createIndexes(database);
  }

  Future<void> _createIndexes(Database database) async {
    await database.execute('CREATE INDEX IF NOT EXISTS idx_patients_name ON patients(full_name)');
    await database.execute('CREATE INDEX IF NOT EXISTS idx_patients_phone ON patients(phone)');
    await database.execute('CREATE INDEX IF NOT EXISTS idx_appointments_date ON appointments(appointment_date)');
    await database.execute('CREATE INDEX IF NOT EXISTS idx_sessions_start ON sessions(start_time)');
    await database.execute('CREATE INDEX IF NOT EXISTS idx_receipts_date ON receipts(receipt_date)');
    await database.execute('CREATE INDEX IF NOT EXISTS idx_expenses_date ON expenses(expense_date)');
    await database.execute('CREATE INDEX IF NOT EXISTS idx_journal_lines_account ON journal_lines(account_id)');
  }

  Future<void> _seed(Database database) async {
    final departments = <Map<String, Object?>>[
      {'name': 'قسم الأطفال', 'responsible': '', 'work_days': 'بحسب الحجز'},
      {'name': 'قسم النساء', 'responsible': '', 'work_days': 'بحسب الحجز'},
      {'name': 'قسم الرجال', 'responsible': '', 'work_days': 'بحسب الحجز'},
      {'name': 'الحجامة والمساج', 'responsible': '', 'work_days': 'بحسب الحجز'},
      {'name': 'الصالة الرياضية', 'responsible': '', 'work_days': 'بحسب الحجز'},
      {'name': 'عيادة التغذية العلاجية', 'responsible': 'د. غمدان أحمد قاسم الجماعي', 'work_days': 'الأربعاء والخميس'},
      {'name': 'عيادة المخ والأعصاب', 'responsible': 'أخصائي المخ والأعصاب', 'work_days': 'يوم واحد شهرياً بحسب الحجز'},
    ];

    for (final department in departments) {
      await database.insert('departments', department, conflictAlgorithm: ConflictAlgorithm.ignore);
    }

    final accounts = <List<Object?>>[
      ['1000', 'الأصول', 'أصول', null],
      ['1100', 'الصندوق الرئيسي', 'أصول', '1000'],
      ['1200', 'البنوك', 'أصول', '1000'],
      ['1300', 'ذمم المرضى والعملاء', 'أصول', '1000'],
      ['1400', 'المخزون', 'أصول', '1000'],
      ['2000', 'الالتزامات', 'التزامات', null],
      ['2100', 'ذمم الموردين', 'التزامات', '2000'],
      ['3000', 'حقوق الملكية', 'حقوق ملكية', null],
      ['3100', 'رأس المال', 'حقوق ملكية', '3000'],
      ['4000', 'الإيرادات', 'إيرادات', null],
      ['4100', 'إيرادات الخدمات الطبية', 'إيرادات', '4000'],
      ['5000', 'المصروفات', 'مصروفات', null],
      ['5100', 'المرتبات والأجور', 'مصروفات', '5000'],
      ['5200', 'الإيجارات', 'مصروفات', '5000'],
      ['5300', 'المستلزمات الطبية', 'مصروفات', '5000'],
      ['5400', 'الكهرباء والمياه', 'مصروفات', '5000'],
      ['5500', 'المصروفات العمومية', 'مصروفات', '5000'],
    ];

    for (final account in accounts) {
      await database.insert(
        'accounts',
        {
          'code': account[0],
          'name': account[1],
          'type': account[2],
          'parent_code': account[3],
        },
        conflictAlgorithm: ConflictAlgorithm.ignore,
      );
    }
  }

  Future<int> addAudit(String action, String reference) {
    return db.insert('audit_log', {
      'action': action,
      'reference': reference,
      'created_at': DateTime.now().toIso8601String(),
    });
  }

  Future<String> nextFileNo() async {
    final rows = await db.rawQuery('''
      SELECT COALESCE(MAX(CAST(SUBSTR(file_no, 2) AS INTEGER)), 0) AS n
      FROM patients WHERE file_no LIKE '#%'
    ''');
    final next = ((rows.first['n'] as num?)?.toInt() ?? 0) + 1;
    return '#${next.toString().padLeft(4, '0')}';
  }

  Future<String> nextNumber(String table, String column, String prefix) async {
    const allowed = <String, String>{
      'receipts': 'receipt_no',
      'expenses': 'expense_no',
      'invoices': 'invoice_no',
    };
    if (allowed[table] != column) {
      throw ArgumentError('جدول أو عمود غير مسموح به.');
    }

    final rows = await db.rawQuery('''
      SELECT COALESCE(MAX(CAST(SUBSTR($column, ${prefix.length + 1}) AS INTEGER)), 0) AS n
      FROM $table WHERE $column LIKE ?
    ''', ['$prefix%']);

    final next = ((rows.first['n'] as num?)?.toInt() ?? 0) + 1;
    return '$prefix${next.toString().padLeft(5, '0')}';
  }

  Future<int> createPatient(Map<String, Object?> data) async {
    return db.transaction((txn) async {
      final id = await txn.insert('patients', data);
      await txn.insert('medical_records', {
        'patient_id': id,
        'created_at': DateTime.now().toIso8601String(),
      });
      await txn.insert('audit_log', {
        'action': 'إنشاء ملف مريض',
        'reference': data['file_no'],
        'created_at': DateTime.now().toIso8601String(),
      });
      return id;
    });
  }

  Future<List<Map<String, Object?>>> patients({String search = ''}) async {
    final text = search.trim();
    if (text.isEmpty) {
      return db.query('patients', orderBy: 'id DESC');
    }
    final q = '%$text%';
    return db.query(
      'patients',
      where: 'full_name LIKE ? OR phone LIKE ? OR file_no LIKE ? OR national_id LIKE ?',
      whereArgs: [q, q, q, q],
      orderBy: 'id DESC',
    );
  }

  Future<Map<String, Object?>?> patient(int id) async {
    final rows = await db.query('patients', where: 'id=?', whereArgs: [id], limit: 1);
    return rows.isEmpty ? null : rows.first;
  }

  Future<List<Map<String, Object?>>> appointments() async {
    return db.rawQuery('''
      SELECT a.*, p.full_name, p.file_no, p.phone
      FROM appointments a
      JOIN patients p ON p.id=a.patient_id
      ORDER BY a.appointment_date DESC
    ''');
  }

  Future<List<Map<String, Object?>>> packages() async {
    return db.rawQuery('''
      SELECT b.*, p.full_name, p.file_no
      FROM packages b
      JOIN patients p ON p.id=b.patient_id
      ORDER BY b.id DESC
    ''');
  }

  Future<List<Map<String, Object?>>> sessions() async {
    return db.rawQuery('''
      SELECT s.*, p.full_name, p.file_no, b.name AS package_name
      FROM sessions s
      JOIN patients p ON p.id=s.patient_id
      LEFT JOIN packages b ON b.id=s.package_id
      ORDER BY s.id DESC
    ''');
  }

  Future<List<Map<String, Object?>>> departments() => db.query('departments', where: 'active=1', orderBy: 'name');

  Future<List<Map<String, Object?>>> staff() => db.query('staff', orderBy: 'id DESC');

  Future<List<Map<String, Object?>>> expenseAccounts() => db.query(
        'accounts',
        where: "type=? AND active=1",
        whereArgs: ['مصروفات'],
        orderBy: 'code',
      );

  Future<int> patientCount() async {
    final rows = await db.rawQuery('SELECT COUNT(*) AS c FROM patients');
    return (rows.first['c'] as num?)?.toInt() ?? 0;
  }

  String _todayPrefix() => DateTime.now().toIso8601String().substring(0, 10);

  Future<int> todayAppointments() async {
    final rows = await db.rawQuery(
      'SELECT COUNT(*) AS c FROM appointments WHERE appointment_date LIKE ?',
      ['${_todayPrefix()}%'],
    );
    return (rows.first['c'] as num?)?.toInt() ?? 0;
  }

  Future<int> todaySessions() async {
    final rows = await db.rawQuery(
      'SELECT COUNT(*) AS c FROM sessions WHERE start_time LIKE ?',
      ['${_todayPrefix()}%'],
    );
    return (rows.first['c'] as num?)?.toInt() ?? 0;
  }

  Future<double> todayReceipts() async {
    final rows = await db.rawQuery(
      'SELECT COALESCE(SUM(amount),0) AS total FROM receipts WHERE receipt_date LIKE ?',
      ['${_todayPrefix()}%'],
    );
    return (rows.first['total'] as num?)?.toDouble() ?? 0;
  }

  Future<double> todayExpenses() async {
    final rows = await db.rawQuery(
      'SELECT COALESCE(SUM(amount),0) AS total FROM expenses WHERE expense_date LIKE ?',
      ['${_todayPrefix()}%'],
    );
    return (rows.first['total'] as num?)?.toDouble() ?? 0;
  }

  Future<double> cashBalance() async {
    final rows = await db.rawQuery('''
      SELECT COALESCE(SUM(debit),0) - COALESCE(SUM(credit),0) AS balance
      FROM journal_lines l
      JOIN accounts a ON a.id=l.account_id
      WHERE a.name=?
    ''', ['الصندوق الرئيسي']);
    return (rows.first['balance'] as num?)?.toDouble() ?? 0;
  }

  Future<double> receivablesBalance() async {
    final rows = await db.rawQuery('''
      SELECT COALESCE(SUM(debit),0) - COALESCE(SUM(credit),0) AS balance
      FROM journal_lines l
      JOIN accounts a ON a.id=l.account_id
      WHERE a.name=?
    ''', ['ذمم المرضى والعملاء']);
    return (rows.first['balance'] as num?)?.toDouble() ?? 0;
  }

  Future<List<Map<String, Object?>>> recentReceipts({int limit = 20}) async {
    return db.rawQuery('''
      SELECT r.*, p.full_name
      FROM receipts r
      LEFT JOIN patients p ON p.id=r.patient_id
      ORDER BY r.id DESC LIMIT ?
    ''', [limit]);
  }

  Future<List<Map<String, Object?>>> recentExpenses({int limit = 20}) async {
    return db.query('expenses', orderBy: 'id DESC', limit: limit);
  }

  Future<void> completeSession(int sessionId) async {
    await db.transaction((txn) async {
      final rows = await txn.query('sessions', where: 'id=?', whereArgs: [sessionId], limit: 1);
      if (rows.isEmpty) throw Exception('الجلسة غير موجودة.');
      final session = rows.first;
      if (session['status'] == 'مكتملة') return;

      final packageId = session['package_id'] as int?;
      if (packageId != null) {
        final packages = await txn.query('packages', where: 'id=?', whereArgs: [packageId], limit: 1);
        if (packages.isEmpty) throw Exception('الباقة المرتبطة غير موجودة.');
        final remaining = (packages.first['remaining_sessions'] as num?)?.toInt() ?? 0;
        if (remaining <= 0) throw Exception('لا توجد جلسات متبقية في الباقة.');
        await txn.update('packages', {'remaining_sessions': remaining - 1}, where: 'id=?', whereArgs: [packageId]);
      }

      final transactionId = session['session_transaction_id'] as String? ??
          'SESSION-$sessionId-${DateTime.now().microsecondsSinceEpoch}';
      await txn.update(
        'sessions',
        {'status': 'مكتملة', 'session_transaction_id': transactionId},
        where: 'id=?',
        whereArgs: [sessionId],
      );
    });
  }

  Future<void> cancelSession(int sessionId) async {
    await db.transaction((txn) async {
      final rows = await txn.query('sessions', where: 'id=?', whereArgs: [sessionId], limit: 1);
      if (rows.isEmpty) return;
      final session = rows.first;
      if (session['status'] == 'ملغاة') return;

      final packageId = session['package_id'] as int?;
      if (session['status'] == 'مكتملة' && packageId != null) {
        final packages = await txn.query('packages', where: 'id=?', whereArgs: [packageId], limit: 1);
        if (packages.isNotEmpty) {
          final remaining = (packages.first['remaining_sessions'] as num?)?.toInt() ?? 0;
          final total = (packages.first['total_sessions'] as num?)?.toInt() ?? 0;
          await txn.update(
            'packages',
            {'remaining_sessions': (remaining + 1).clamp(0, total)},
            where: 'id=?',
            whereArgs: [packageId],
          );
        }
      }
      await txn.update('sessions', {'status': 'ملغاة'}, where: 'id=?', whereArgs: [sessionId]);
    });
  }

  Future<int> createBalancedJournal({
    required String description,
    required List<Map<String, Object?>> lines,
    String? referenceType,
    int? referenceId,
  }) async {
    final debit = lines.fold<double>(0, (sum, line) => sum + ((line['debit'] as num?)?.toDouble() ?? 0));
    final credit = lines.fold<double>(0, (sum, line) => sum + ((line['credit'] as num?)?.toDouble() ?? 0));
    if ((debit - credit).abs() > 0.001) {
      throw Exception('القيد غير متوازن: المدين $debit والدائن $credit');
    }

    return db.transaction((txn) => _insertJournal(
          txn,
          description: description,
          lines: lines,
          referenceType: referenceType,
          referenceId: referenceId,
        ));
  }

  Future<int> _insertJournal(
    DatabaseExecutor executor, {
    required String description,
    required List<Map<String, Object?>> lines,
    String? referenceType,
    int? referenceId,
  }) async {
    final now = DateTime.now().toIso8601String();
    final entryNo = 'JE${DateTime.now().microsecondsSinceEpoch}';
    final id = await executor.insert('journal_entries', {
      'entry_no': entryNo,
      'entry_date': now,
      'description': description,
      'reference_type': referenceType,
      'reference_id': referenceId,
      'created_at': now,
    });
    for (final line in lines) {
      await executor.insert('journal_lines', {...line, 'journal_id': id});
    }
    return id;
  }

  Future<int> createReceipt({
    required int patientId,
    required double amount,
    required String description,
  }) async {
    if (amount <= 0) throw Exception('المبلغ يجب أن يكون أكبر من صفر.');

    return db.transaction((txn) async {
      final cash = await _accountId(txn, 'الصندوق الرئيسي');
      final receivable = await _accountId(txn, 'ذمم المرضى والعملاء');
      final number = await _nextNumberTxn(txn, 'receipts', 'receipt_no', 'RV');
      final now = DateTime.now().toIso8601String();

      final receiptId = await txn.insert('receipts', {
        'receipt_no': number,
        'patient_id': patientId,
        'receipt_date': now,
        'amount': amount,
        'account_name': 'الصندوق الرئيسي',
        'description': description,
      });

      await _insertJournal(
        txn,
        description: 'سند قبض $number',
        referenceType: 'receipt',
        referenceId: receiptId,
        lines: [
          {'account_id': cash, 'debit': amount, 'credit': 0.0, 'description': 'قبض'},
          {'account_id': receivable, 'debit': 0.0, 'credit': amount, 'description': 'قبض من مريض'},
        ],
      );

      await txn.insert('audit_log', {
        'action': 'إنشاء سند قبض',
        'reference': number,
        'created_at': now,
      });

      return receiptId;
    });
  }

  Future<Map<String, Object?>> receiptById(int id) async {
    final rows = await db.rawQuery('''
      SELECT r.*, p.full_name, p.phone
      FROM receipts r LEFT JOIN patients p ON p.id=r.patient_id
      WHERE r.id=? LIMIT 1
    ''', [id]);
    if (rows.isEmpty) throw Exception('سند القبض غير موجود.');
    return rows.first;
  }

  Future<int> createExpense({
    required String category,
    required double amount,
    required String description,
  }) async {
    if (amount <= 0) throw Exception('المبلغ يجب أن يكون أكبر من صفر.');

    return db.transaction((txn) async {
      final cash = await _accountId(txn, 'الصندوق الرئيسي');
      final expense = await _accountId(txn, category.isEmpty ? 'المصروفات العمومية' : category);
      final number = await _nextNumberTxn(txn, 'expenses', 'expense_no', 'EX');
      final now = DateTime.now().toIso8601String();

      final expenseId = await txn.insert('expenses', {
        'expense_no': number,
        'expense_date': now,
        'category': category.isEmpty ? 'المصروفات العمومية' : category,
        'amount': amount,
        'description': description,
      });

      await _insertJournal(
        txn,
        description: 'مصروف $number',
        referenceType: 'expense',
        referenceId: expenseId,
        lines: [
          {'account_id': expense, 'debit': amount, 'credit': 0.0, 'description': description},
          {'account_id': cash, 'debit': 0.0, 'credit': amount, 'description': description},
        ],
      );

      await txn.insert('audit_log', {
        'action': 'إنشاء سند صرف',
        'reference': number,
        'created_at': now,
      });

      return expenseId;
    });
  }

  Future<int> _accountId(DatabaseExecutor executor, String name) async {
    final rows = await executor.query('accounts', columns: ['id'], where: 'name=? AND active=1', whereArgs: [name], limit: 1);
    if (rows.isEmpty) throw Exception('الحساب "$name" غير موجود في دليل الحسابات.');
    return (rows.first['id'] as num).toInt();
  }

  Future<String> _nextNumberTxn(DatabaseExecutor executor, String table, String column, String prefix) async {
    final rows = await executor.rawQuery('''
      SELECT COALESCE(MAX(CAST(SUBSTR($column, ${prefix.length + 1}) AS INTEGER)), 0) AS n
      FROM $table WHERE $column LIKE ?
    ''', ['$prefix%']);
    final next = ((rows.first['n'] as num?)?.toInt() ?? 0) + 1;
    return '$prefix${next.toString().padLeft(5, '0')}';
  }

  Future<Map<String, double>> trialBalance() async {
    final rows = await db.rawQuery('''
      SELECT a.code, a.name,
        COALESCE(SUM(l.debit),0) AS debit,
        COALESCE(SUM(l.credit),0) AS credit
      FROM accounts a
      LEFT JOIN journal_lines l ON l.account_id=a.id
      GROUP BY a.id, a.code, a.name
      ORDER BY a.code
    ''');
    return {
      for (final row in rows)
        '${row['code']} - ${row['name']}':
            ((row['debit'] as num?)?.toDouble() ?? 0) - ((row['credit'] as num?)?.toDouble() ?? 0),
    };
  }
}
